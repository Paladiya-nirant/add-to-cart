let pro = JSON.parse(localStorage.getItem("card"));
let product = document.getElementById("i_p");

pro.forEach((item) => {

    product.innerHTML += `<ul class="d-flex align-items-center border mb-4 justify-content-between nav">
        <li class="m-2 image flex-column"> 
            <img src="${item.thumbnail}" class="img i1" alt="m1" width="100%">
        </li>
        <li class="m-2 p-1">${item.brand}</li>
        <li class="m-2 p-1">${item.category}</li>
        <li class="m-2 p-1">${item.price}</li>
        <li class="m-2 p-1">
            <button class="butt" onclick="return deleteItemData(${item.id})">Delete</button>
        </li>
    </ul>`

});

const deleteItemData = (id) => {
    pro = JSON.parse(localStorage.getItem("card"));
    let array = [];

    pro.forEach((ele) => {
        if(ele.id!=id)
        {
            array.push(ele);
        }
    });

    localStorage.setItem('card', JSON.stringify(array));
   let carddata = JSON.parse(localStorage.getItem("card"));
   product.innerHTML = '';
   carddata.forEach((pro) => {

    product.innerHTML += `<ul class="d-flex align-items-center border mb-4 justify-content-between nav">
    <li class="m-2 image flex-column"> 
        <img src="${pro.thumbnail}" class="img i1" alt="m1" width="100%">
    </li>
    <li class="m-2 p-1">${pro.brand}</li>
    <li class="m-2 p-1">${pro.category}</li>
    <li class="m-2 p-1">${pro.price}</li>
    <li class="m-2 p-1">
        <button class="butt" onclick="return deleteItemData(${pro.id})">Delete</button>
    </li>
</ul>`
   })

}